# -*- coding: utf-8 -*-

'''
Copyright (C) 2015                                                     

This program is free software: you can redistribute it and/or modify   
it under the terms of the GNU General Public License as published by   
the Free Software Foundation, either version 3 of the License, or      
(at your option) any later version.                                    

This program is distributed in the hope that it will be useful,        
but WITHOUT ANY WARRANTY; without even the implied warranty of         
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          
GNU General Public License for more details.                           

You should have received a copy of the GNU General Public License      
along with this program. If not, see <http://www.gnu.org/licenses/>  
'''                                                                           

import urllib, urllib2, re, os, sys, shutil
import xbmc, xbmcplugin, xbmcgui, xbmcaddon

mysettings = xbmcaddon.Addon(id = 'plugin.video.add_sources_xml')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
logos = xbmc.translatePath(os.path.join(home, 'resources/logos/'))

new_sources = xbmc.translatePath(os.path.join(home, 'sources.xml'))	
sources_xml = xbmc.translatePath('special://home/userdata/sources.xml')
sources_bak = xbmc.translatePath('special://home/userdata/sources_bak.xml')

def home():
	add_dir('Nhấn vô đây để copy [COLOR red][B]sources.xml[/B][/COLOR] vào XBMC or Kodi.', 'copy_sources', 1, icon, fanart)

def main():
	try:	
		if not os.path.exists(sources_bak):
			try:
				os.rename(sources_xml, sources_bak)
			except: 
				pass
			shutil.copy(new_sources, sources_xml)
			xbmcgui.Dialog().ok(
									'add_sources_xml',  
									'[B]Cám ơn bạn thanh51 đã cho biết các video sources này.[/B]',
									'[COLOR red][B]Restart XBMC-Kodi. Vào VIDEOS > Files > thưởng thức[/B][/COLOR]',
									'Done.'
								)
		else: 
			xbmcgui.Dialog().ok(
									'add_sources_xml', 
									'[B]Sorry, máy này đã có sources_bak.xml.[/B]', 
									'[COLOR red][B]Bạn cần tự copy sources.xml vào userdata[/B][/COLOR]', 
									'http://kodi.wiki/view/userdata'
								)			
	except:
		pass
		
def get_params():
	param = []
	paramstring = sys.argv[2]
	if len(paramstring)>= 2:
		params = sys.argv[2]
		cleanedparams = params.replace('?', '')
		if (params[len(params)-1] == '/'):
			params = params[0:len(params)-2]
		pairsofparams = cleanedparams.split('&')
		param = {}
		for i in range(len(pairsofparams)):
			splitparams = {}
			splitparams = pairsofparams[i].split('=')
			if (len(splitparams)) == 2:
				param[splitparams[0]] = splitparams[1]
	return param

def add_dir(name, url, mode, iconimage, fanart):
	u = (	
			sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + 
			"&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)
		)	
	ok = True
	liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
	return ok

params = get_params()
url = None
name = None
mode = None
iconimage = None

try:
	url = urllib.unquote_plus(params["url"])
except:
	pass
try:
	name = urllib.unquote_plus(params["name"])
except:
	pass
try:
	mode = int(params["mode"])
except:
	pass
try:
	iconimage = urllib.unquote_plus(params["iconimage"])
except:
	pass  
 
print "Mode: " + str(mode)
print "URL: " + str(url)
print "Name: " + str(name)
print "iconimage: " + str(iconimage)

if mode == None or url == None or len(url)<1:
	home()

elif mode == 1:
	main()
	sys.exit(0)
xbmcplugin.endOfDirectory(int(sys.argv[1]))